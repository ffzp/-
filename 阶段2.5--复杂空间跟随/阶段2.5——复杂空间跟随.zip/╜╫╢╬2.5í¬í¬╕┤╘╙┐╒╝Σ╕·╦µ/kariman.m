clear;clc; close
N=100;
%kalman init
P_last = 0.02;
P_now = 0.0;
Q_cov = 0.000001; %过程激励噪声协方差,参数可调
R_cov = 1.543; %测量噪声协方差，与仪器测量的性质有关，参数可调
%x_last = 0.0;
K = 0.0;
out = 0.0;
%standard&bias
creat_time=1:2*N+1;
target_point=zeros(size(creat_time,2),3);
for i=1:size(target_point,1)
    target_point(i,:)=[5*cos(0.2*creat_time(i)) 2*tan(0.002*creat_time(i)) 5*sin(0.2*creat_time(i))+0.8];
    y(i)=target_point(i,1);
end
for h=1:3
    creat_time=1:size(target_point,1);
    x=creat_time;
    for i=1:size(target_point,1)
        y(i)=target_point(i,h);
    end
    %y=0;
    % bias = randn(1,2*N+1);
    y_bias = y;

    %%%%%kalman
    x_last = y_bias(1);
    out(1)=0;
    for i=1:size(target_point,1)
        z=y_bias(i);

        P_now = P_last + Q_cov;
        K = P_now / (P_now + R_cov );
        x_last = x_last + K * (z - x_last);
        P_last = (1 - K)* P_now;
        out(i) = x_last;
    end
    %%%%一阶低通滤波
    k=0.565;
    ditong_filter(1)=0;
    for j=2:size(target_point,1)
        ditong_filter(j)=k*y_bias(j)+(1-k)*y_bias(j-1);
    end
    for i=2:size(target_point,1)
        target_point(i,h)=ditong_filter(1,i);
    end
end
plot(x,y,x,y_bias,x,out,x,ditong_filter);
