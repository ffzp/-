clear;clc;close all
creat_time=1:100;
target_point=zeros(size(creat_time,2),3);
for i=1:size(target_point,1)
    target_point(i,:)=[5*cos(0.2*creat_time(i)) 2*tan(0.002*creat_time(i)) 5*sin(0.2*creat_time(i))+0.8];
end
initial_point=[-3 0 -0.5];
%% pid控制
% pid参数
kp=0.2;  ki=0.2;  kd=0.01;  %预设初始值
pid=[kp,ki,kd];             %迭代值
exceed_times=[150 500 50];%设置迭代次数
% 进行迭代控制；
for h=1:3
    flag=1;                               %迭代控制信号
    bottle_2=0;                           %迭代效果判断器
    flag_2=1;                             %迭代方向判断器
    count=0;                              %迭代终止器，防止迭代次数过多；
    erro_min=0; k_min=pid(h); flag_3=1;    %迭代次数中最小的情况                
    while flag
        Pathway_point=zeros(size(target_point));
        Pathway_point(1,:)=initial_point;
        % 使用的工具
        sum=0;bottle=0;
        for i=2:size(creat_time,2)
            % 进行误差计算
            error=target_point(i,:)-Pathway_point(i-1,:);
            error_value=norm(error);
            % 进行进给计算
            feed_n=error_value*pid(1)+pid(2)*sum+pid(3)*(error_value-bottle);
            %进行速度反馈,使速度变化较小
            %进行速度上限设计
            if bottle==0
                if feed_n>0.6
                    feed_n=0.6;
                end
            end
            if bottle~=0
                if feed_n>=1.1*bottle
                    feed_n=1.1*bottle;
                elseif feed_n<=0.8*bottle
                    feed_n=0.8*bottle;
                end
            end
            %进行二次误差反馈：
            if bottle~=0
                if abs(error_value)<=0.01
                    if abs(error_value-feed_n)>=0.005
                        feed_n=feed_n+(error_value-feed_n)*0.2;
                    end
                end
            end
            sum=sum+error_value;
            if size(creat_time,2)>=100
                if sum>=100*norm(error)
                    sum=0;
                end
                if sum>=60
                    sum=0;
                end
            end
            %开始倒水
            bottle=feed_n;
            %计算轨迹点
            Pathway_point(i,:)=Pathway_point(i-1,:)+feed_n*error;
        end
        error_final=norm(target_point(i,:)-Pathway_point(i,:));
        if count==exceed_times(h)+1
            break
        end
        %获取最小值
        if bottle_2==0
            erro_min=error_final;
        end
        %进行迭代最小值的记录
        if abs(error_final)<=abs(erro_min)
            erro_min=error_final;
            k_min=pid(h);
        end
        %开始迭代控制
        if flag_3==1
            if error_final<=0.0001
                flag=0;
            %调整迭代方向
            elseif flag_2==1
                pid(h)=pid(h)+0.001;
            else
                pid(h)=pid(h)-0.001;
            end
            if bottle_2~=0
                if bottle_2-error_final<0
                    flag_2=0;
                end
            end
        end
        bottle_2=error_final;
        %防止超限调整
        if count==exceed_times(h)
            pid(h)=k_min;
            flag_3=0;
        end
        count=count+1;
    end
end
%% 清除变量
clear flag flag_3 flag_2 creat_time bottle_2 bottle error_value error feed_n exceed_times ki kd kp h i erro_min k_min
%% 开始绘图
%plot3(Pathway_point(:,1),Pathway_point(:,2),Pathway_point(:,3),'LineWidth',1.5,'Color','b')
%防止散点图出问题
plot3(target_point(:,1),target_point(:,2),target_point(:,3),'LineWidth',1.5,'Color','r'); hold on;
scatter3(Pathway_point(:,1),Pathway_point(:,2),Pathway_point(:,3),abs(Pathway_point(:,3)*100),Pathway_point(:,3),'.','SizeData',300);