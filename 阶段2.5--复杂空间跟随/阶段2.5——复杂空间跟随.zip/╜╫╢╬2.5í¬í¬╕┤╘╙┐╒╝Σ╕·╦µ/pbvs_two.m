clear,clc,close all;
angle=pi/180;
%%
%建立DH表
a = [0, -0.42500, -0.39225, 0, 0, 0];
d = [0.089159, 0, 0, 0.10915, 0.09465, 0.08230];
alpha = [pi/2, 0, 0, pi/2, -pi/2, 0];
% 建立UR5机械臂模型
L1 = Link('d', d(1),  'a', a(1), 'alpha', alpha(1),  'standard');
L2 = Link('d', d(2),  'a', a(2), 'alpha', alpha(2),  'standard');
L3 = Link('d', d(3),  'a', a(3), 'alpha', alpha(3),  'standard');
L4 = Link('d', d(4),  'a', a(4), 'alpha', alpha(4),  'standard');
L5 = Link('d', d(5),  'a', a(5), 'alpha', alpha(5),  'standard');
L6 = Link('d', d(6),  'a', a(6), 'alpha', alpha(6),  'standard');
robot = SerialLink([L1,L2,L3,L4,L5,L6], 'name', 'UR5');
%检查
robot.tool=transl(0,0,0.2);
robot.base=transl(0,0,0);
initial_angel=[0,-pi/2,0,0,pi/2,0];
World=[-2,+2,-2,+2,-2,+2];
%robot.plot(target_angl,'tilesize',0.15,'workspace',World);
%%
%建立圆
circle_center=[0.6,0.45,0.3];
circle_size=0.05;
circle_n=[1 1 -1];
%moving_circle(circle_center,circle_n,circle_size)
hold on
%%
transl_vector=0.3*circle_n/norm(circle_n);
target_pose =transl(circle_center-transl_vector)*rotate(circle_n);
target_angel=ur5_ikine_single(robot,target_pose);
targrt_pose=robot.fkine(target_angel);
%% 第一段轨迹插值
step=30;
[q1 ,~, ~]=jtraj(initial_angel,target_angel,step);
grid on
T=robot.fkine(q1);						%根据插值，得到末端执行器位姿
nT=T.T;
plot3(squeeze(nT(1,4,:)),squeeze(nT(2,4,:)),squeeze(nT(3,4,:)));%输出末端轨迹
title('输出末端轨迹');
robot.plot(q1,'workspace',World);
%% 生成跟随轨迹
% 生成目标点
speed=0.014*[-1 0.5 -0.5];
target_point=zeros(30,3);
for i=1:size(target_point,1)
    target_point(i,:)=circle_center+speed*i;
    target_point(i,3)=target_point(i,3)+0.1*sin(0.2*i)+0.01*randn(1);
    target_point(i,1)=target_point(i,1)-0.3*cos(0.2*i)-0.01*randn(1);
    target_point(i,2)=target_point(i,2)+0.00005*tan(0.2*i)+0.05*randn(1);
end
%展现加入噪声后的点
scatter3(target_point(:,1),target_point(:,2),target_point(:,3),'filled','SizeData',10); hold on;
%进行滤波：
target_point=kalman(target_point);
%计算机械臂的途径轨迹
now_position=pid_final_version(target_point,circle_center-transl_vector);
initial_pose=transl(circle_center-transl_vector)*rotate(circle_n);
initial_angel=target_angel;
%开始轨迹规划
for i=1:size(now_position,1)
    circle_center=target_point(i,:);
    building_circle(circle_n,circle_size,circle_center)
    targrt_pose=transl(now_position(i,:))*rotate(circle_n);
    target_angel_n=UR5ikine(robot,targrt_pose);
    %选择距离最近的关节角
    target_angel=bright_c_selector(initial_angel,target_angel_n);
    step=5;
    q1=zeros(step,6);
    for j=1:step
            q1(j,:)=(target_angel-initial_angel)/step*j+initial_angel;
    end
%     [q1 ,qd1, qdd1]=jtraj(initial_angel,target_angel,step);
%     T=robot.fkine(q1);						%根据插值，得到末端执行器位姿
    nT=T.T;
    plot3(squeeze(nT(1,4,:)),squeeze(nT(2,4,:)),squeeze(nT(3,4,:)));%输出末端轨迹
    title('输出末端轨迹');
    robot.plot(q1,'workspace',World);
    initial_angel=target_angel;
end
%% 计算误差
error=zeros(size(now_position,1),1);
for i=1:size(now_position,1)
    error(i)=norm(now_position(i,:)-target_point(i,:));
end
% 误差展现
figure
a=1:size(now_position,1);
c = polyfit(a, error, 5); %进行拟合，c为5次拟合后的系数
d = polyval(c, a, 1); %拟合后，每一个横坐标对应的值即为d
plot(a, d, 'r','LineWidth',1.5); %拟合后的曲线