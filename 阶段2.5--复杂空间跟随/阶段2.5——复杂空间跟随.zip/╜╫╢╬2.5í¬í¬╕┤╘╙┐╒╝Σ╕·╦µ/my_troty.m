function resualt = my_troty(thea)
t=[cos(thea) 0 sin(thea);0 1 0;-sin(thea) 0 cos(thea)];
resualt=zeros(4,4);
for i=1:3
    for j=1:3
    resualt(i,j)=t(i,j);
    end
end
resualt(4,4)=1;
end