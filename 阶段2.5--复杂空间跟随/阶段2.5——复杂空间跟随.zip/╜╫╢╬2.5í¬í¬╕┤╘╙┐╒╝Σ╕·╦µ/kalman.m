function resualt= kalman(target_point)
%UNTITLED4 此处提供此函数的摘要
%   此处提供详细说明
P_last = 0.02;
% P_now = 0.0;
Q_cov = 0.05; %过程激励噪声协方差,参数可调
R_cov = 0.543; %测量噪声协方差，与仪器测量的性质有关，参数可调
%x_last = 0.0;
% K = 0.0;
for h=1:3
    creat_time=1:size(target_point,1);
    y=zeros(1,size(target_point,1));
    for i=1:size(target_point,1)
        y(i)=target_point(i,h);
    end
    %y=0;
    % bias = randn(1,2*N+1);
    y_bias = y;

    %%%%%kalman
    x_last = y_bias(1);
    out=zeros(1,size(creat_time,2));
    ditong_filter=zeros(1,size(creat_time,2));
    for i=1:size(target_point,1)
        z=y_bias(i);
        P_now = P_last + Q_cov;
        K = P_now / (P_now + R_cov );
        x_last = x_last + K * (z - x_last);
        P_last = (1 - K)* P_now;
        out(i) = x_last;
    end
    %%%%一阶低通滤波
    k=0.565;
    ditong_filter(1)=0;
    for j=2:size(target_point,1)
        ditong_filter(j)=k*y_bias(j)+(1-k)*y_bias(j-1);
    end
    for i=2:size(target_point,1)
        target_point(i,h)=out(1,i);
    end
end
clear x y;
resualt=target_point;
end